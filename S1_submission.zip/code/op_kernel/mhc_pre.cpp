#include "kernel_operator.h"
#include "lib/matmul_intf.h"

#include "mhc_pre_tiling.h"
#include "tiling_key_mhc_pre.h"

using namespace AscendC;

namespace {
// 深度 2 让 MTE 搬运和 Vector 计算真正流水起来; 深度 1 时每次 DeQue 都要等搬运完成。
// A2 上同一 TPosition 的队列受同步事件资源限制, 本内核所有 TQue 深度恒为 2。
constexpr uint32_t kQueueDepth = 2;
// 后处理按 8 行成组流水: 组内只有 1 次 MTE2 同步, 用组粒度摊薄同步与指令开销。
constexpr uint32_t kPostGroupRows = 8;
// hIn 批量归约时 x 沿 D 的分片上限(元素), 控制 x 缓冲与 fp32 暂存的 UB 占用。
constexpr uint32_t kHinTileElements = 1024;
// 前处理里每多少行做一次标量往返(V->S 会冲刷流水, 逐行做代价极高)
constexpr uint32_t kSumBatchRows = 64;
constexpr uint32_t kFloatBlockElements = 8;
// hMix / bias 的三段(pPre[n] / pPost[n] / pRes[n*n])各自落在 32B 对齐的槽位上
constexpr uint32_t kSlotPost = 8;
constexpr uint32_t kSlotRes = 16;
constexpr uint32_t kSlotBufElements = 96;   // 16 + n*n, n<=8
constexpr uint64_t kAivToAicFlag = 8;
constexpr uint64_t kAicToAivFlag = 9;
// CANN 8.0's MIX 1:2 cross-core mode is the literal value 2; the contest
// toolchain does not export the newer symbolic alias.
constexpr uint64_t kCrossCoreSyncMode = 2;

// This is the same direct MatmulImpl configuration used by CANN 8.0's
// official V220 MhcPre kernel.  It executes locally on the AIC and therefore
// avoids the KFC server/client registration framework entirely.
constexpr MatmulConfig kDirectMatmulConfig =
    GetMDLConfig(true, false, 0, false, false, false, true);

__aicore__ inline uint64_t MinU64(uint64_t lhs, uint64_t rhs)
{
    return lhs < rhs ? lhs : rhs;
}

__aicore__ inline uint64_t CeilDivU64(uint64_t value, uint64_t divisor)
{
    return (value + divisor - 1) / divisor;
}

// ---- 批量 hIn 归约辅助函数(自官方 ops-transformer mhc_pre_base.h 原样移植,
//      随 batchY 配置在评测机通过, 保持逐 stream 的浮点累加顺序)----
constexpr int32_t kBlkSize = 32;
constexpr int32_t kOneRepeatBlockNums = 8;
constexpr int32_t kRepeatSize = 256;
constexpr int32_t kMaxRepeatStride = 255;

__aicore__ inline int32_t CeilDivI32(int32_t a, int32_t b)
{
    return b == 0 ? a : (a + b - 1) / b;
}

__aicore__ inline int32_t CeilAlignI32(int32_t a, int32_t b)
{
    return CeilDivI32(a, b) * b;
}

template <typename T>
__aicore__ inline int32_t RoundUpBlock(int32_t num)
{
    return CeilAlignI32(num, kBlkSize / static_cast<int32_t>(sizeof(T)));
}

// output/input0 形状 = curRowNum 行 x curColNum 列(行对齐 RoundUpBlock<float>);
// input1 = 每行 n(numN) 个权重; tmpBuffer 承接 Brcb 广播(>=16 block)。
template <typename T>
__aicore__ inline void MulABLastDimBrcInline2(const LocalTensor<T> &output,
                                              const LocalTensor<T> &input0,
                                              const LocalTensor<T> &input1,
                                              const LocalTensor<T> &tmpBuffer,
                                              int32_t curRowNum, int32_t curColNum, int32_t numN)
{
    uint32_t elemInOneBlock = kBlkSize / sizeof(T);
    uint32_t repeatTimes =
        static_cast<uint32_t>(CeilDivI32(curRowNum * CeilDivI32(elemInOneBlock, numN),
                                         kOneRepeatBlockNums));
    Brcb(tmpBuffer, input1, repeatTimes, {1, 8});   // 每个权重复制 8 份到一块
    PipeBarrier<PIPE_V>();
    uint32_t elemInOneRepeat = kRepeatSize / sizeof(T);
    uint32_t curColNumAlign = static_cast<uint32_t>(RoundUpBlock<T>(curColNum));
    if (curColNum <= static_cast<int32_t>(elemInOneBlock)) {
        Mul(output, input0, tmpBuffer, curRowNum * curColNumAlign);
    } else {
        int32_t numRepeatPerLine = curColNum / elemInOneRepeat;
        int32_t numRemainPerLine = curColNum % elemInOneRepeat;
        int32_t dstRepStridePerLine = CeilDivI32(curColNum, elemInOneBlock);
        BinaryRepeatParams instrParams;
        if (numRepeatPerLine > 0) {
            if (dstRepStridePerLine > kMaxRepeatStride || curRowNum < numRepeatPerLine) {
                // Col 方向开 repeat: 每行一次, src1 锁定在对应权重的广播块
                instrParams.dstBlkStride = 1;
                instrParams.src0BlkStride = 1;
                instrParams.src1BlkStride = 0;
                instrParams.dstRepStride = 8;
                instrParams.src0RepStride = 8;
                instrParams.src1RepStride = 0;
                for (int32_t i = 0; i < curRowNum; i++) {
                    Mul(output[i * curColNumAlign], input0[i * curColNumAlign],
                        tmpBuffer[(i / numN * elemInOneBlock + i % numN) * elemInOneBlock],
                        elemInOneRepeat, numRepeatPerLine, instrParams);
                }
            } else {
                // Row 方向开 repeat: src1 每个 repeat 前进一个广播块
                instrParams.dstBlkStride = 1;
                instrParams.src0BlkStride = 1;
                instrParams.src1BlkStride = 0;
                instrParams.dstRepStride = dstRepStridePerLine;
                instrParams.src0RepStride = dstRepStridePerLine;
                instrParams.src1RepStride = 1;
                for (int32_t i = 0; i < numRepeatPerLine; i++) {
                    Mul(output[i * elemInOneRepeat], input0[i * elemInOneRepeat], tmpBuffer,
                        elemInOneRepeat, curRowNum, instrParams);
                }
            }
        }
        if (numRemainPerLine > 0) {
            instrParams.dstBlkStride = 1;
            instrParams.src0BlkStride = 1;
            instrParams.src1BlkStride = 0;
            instrParams.dstRepStride = 0;
            instrParams.src0RepStride = 0;
            instrParams.src1RepStride = 0;
            for (int32_t i = 0; i < curRowNum; i++) {
                Mul(output[numRepeatPerLine * elemInOneRepeat + i * curColNumAlign],
                    input0[numRepeatPerLine * elemInOneRepeat + i * curColNumAlign],
                    tmpBuffer[(i / numN * elemInOneBlock + i % numN) * elemInOneBlock],
                    numRemainPerLine, 1, instrParams);
            }
        }
    }
    PipeBarrier<PIPE_V>();
}

// input 布局 = dim0 x dim1 x dim2(行对齐 RoundUpBlock<float>), 沿 dim1 归约到
// output[dim0][dim2]; 每行从"第 0 个 dim1 行"起累加, 舍入顺序与逐 stream 累加一致。
__aicore__ inline void ReduceSumARAPerf(const LocalTensor<float> &output,
                                        const LocalTensor<float> &input,
                                        uint32_t dim0, uint32_t dim1, uint32_t dim2)
{
    uint32_t elemInOneBlock = 8;
    uint32_t elemInOneRepeat = 64;
    uint32_t dim2Align = static_cast<uint32_t>(RoundUpBlock<float>(dim2));
    DataCopyParams copyParams;
    copyParams.blockCount = dim0;
    copyParams.blockLen = dim2Align / elemInOneBlock;
    copyParams.srcStride = (dim1 - 1) * (dim2Align / elemInOneBlock);
    copyParams.dstStride = 0;
    DataCopy(output, input, copyParams);
    PipeBarrier<PIPE_V>();
    uint32_t dim2RepeatTimes = dim2 / elemInOneRepeat;
    uint32_t dim2Reminder = dim2 % elemInOneRepeat;
    BinaryRepeatParams instrParams;
    instrParams.dstBlkStride = 1;
    instrParams.src0BlkStride = 1;
    instrParams.src1BlkStride = 1;
    instrParams.dstRepStride = 8;
    instrParams.src0RepStride = 8;
    instrParams.src1RepStride = 8;
    for (uint32_t i = 0; i < dim0; i++) {
        for (uint32_t j = 1; j < dim1; j++) {
            if (dim2RepeatTimes > 0) {
                Add(output[i * dim2Align], output[i * dim2Align],
                    input[i * dim1 * dim2Align + j * dim2Align],
                    elemInOneRepeat, dim2RepeatTimes, instrParams);
            }
            if (dim2Reminder != 0) {
                Add(output[i * dim2Align + dim2RepeatTimes * elemInOneRepeat],
                    output[i * dim2Align + dim2RepeatTimes * elemInOneRepeat],
                    input[i * dim1 * dim2Align + j * dim2Align + dim2RepeatTimes * elemInOneRepeat],
                    dim2Reminder, 1, instrParams);
            }
            PipeBarrier<PIPE_V>();
        }
    }
    PipeBarrier<PIPE_V>();
}
} // namespace

template <typename DT_X>
class KernelMhcPre {
public:
    using AType = matmul::MatmulType<TPosition::GM, CubeFormat::ND, float>;
    using BType = matmul::MatmulType<TPosition::GM, CubeFormat::ND, float, true>;
    using CType = matmul::MatmulType<TPosition::GM, CubeFormat::ND, float>;

    matmul::MatmulImpl<AType, BType, CType, CType, kDirectMatmulConfig> matmulObj;

    __aicore__ inline KernelMhcPre() {}

    __aicore__ inline void Init(GM_ADDR x, GM_ADDR phi, GM_ADDR alpha, GM_ADDR bias, GM_ADDR gamma,
                                GM_ADDR hIn, GM_ADDR hPost, GM_ADDR hRes, GM_ADDR userWorkspace,
                                const MhcPreTilingData *tiling, TPipe *pipe)
    {
        tiling_ = tiling;
        pipe_ = pipe;

        xGm_.SetGlobalBuffer((__gm__ DT_X *)x);
        phiGm_.SetGlobalBuffer((__gm__ float *)phi);
        alphaGm_.SetGlobalBuffer((__gm__ float *)alpha);
        biasGm_.SetGlobalBuffer((__gm__ float *)bias);
        if (tiling_->hasGamma != 0) {
            gammaGm_.SetGlobalBuffer((__gm__ float *)gamma);
        }
        hInGm_.SetGlobalBuffer((__gm__ DT_X *)hIn);
        hPostGm_.SetGlobalBuffer((__gm__ float *)hPost);
        hResGm_.SetGlobalBuffer((__gm__ float *)hRes);

        const uint64_t xGammaElements =
            static_cast<uint64_t>(tiling_->batchSeq) * tiling_->flatDim;
        const uint64_t invRmsElements = tiling_->batchSeq;
        xGammaGm_.SetGlobalBuffer((__gm__ float *)userWorkspace);
        invRmsGm_.SetGlobalBuffer((__gm__ float *)userWorkspace + xGammaElements);
        hMixGm_.SetGlobalBuffer((__gm__ float *)userWorkspace + xGammaElements + invRmsElements);

        if ASCEND_IS_AIV {
            InitVectorBuffers();
        }
    }

    __aicore__ inline void Process()
    {
        if ASCEND_IS_AIV {
            // 保持官方验证过的单轮协议: 先把整轮 xGamma 写完, 再等 AIC 完成矩阵乘,
            // 最后统一做后处理。正确性优先, 性能优化放在核内流水。
            uint64_t rowStart = 0;
            uint64_t rowCount = 0;
            GetVectorRowRange(rowStart, rowCount);
            PreprocessRows(rowStart, rowCount);
            CrossCoreSetFlag<kCrossCoreSyncMode, PIPE_MTE3>(kAivToAicFlag);
            CrossCoreWaitFlag(kAicToAivFlag);
            PostprocessRows(rowStart, rowCount);
        }
        if ASCEND_IS_AIC {
            CrossCoreWaitFlag(kAivToAicFlag);
            ProjectWithCube();
            CrossCoreSetFlag<kCrossCoreSyncMode, PIPE_FIX>(kAicToAivFlag);
        }
    }

private:
    __aicore__ inline void SyncVectorToScalar() const
    {
        const event_t eventId =
            static_cast<event_t>(pipe_->FetchEventID(HardEvent::V_S));
        SetFlag<HardEvent::V_S>(eventId);
        WaitFlag<HardEvent::V_S>(eventId);
    }

    __aicore__ inline void SyncMte2ToVector() const
    {
        const event_t eventId =
            static_cast<event_t>(pipe_->FetchEventID(HardEvent::MTE2_V));
        SetFlag<HardEvent::MTE2_V>(eventId);
        WaitFlag<HardEvent::MTE2_V>(eventId);
    }

    __aicore__ inline void SyncScalarToVector() const
    {
        const event_t eventId =
            static_cast<event_t>(pipe_->FetchEventID(HardEvent::S_V));
        SetFlag<HardEvent::S_V>(eventId);
        WaitFlag<HardEvent::S_V>(eventId);
    }

    __aicore__ inline void InitVectorBuffers()
    {
        const uint32_t tileElements = tiling_->tileElements;
        hInTile_ = static_cast<uint32_t>(
            MinU64(static_cast<uint64_t>(kHinTileElements), tiling_->headDim));

        // 单轮协议下 AIV 阶段串行, 各队列深度 2 即可。
        pipe_->InitBuffer(xQueue_, kQueueDepth, tileElements * sizeof(DT_X));
        pipe_->InitBuffer(xCastQueue_, kQueueDepth, tileElements * sizeof(float));
        // 组级输出缓冲: 一次容纳一整组(kPostGroupRows 行 x 96 槽位)的 hPost/hRes
        pipe_->InitBuffer(floatOutQueue_, kQueueDepth,
                          kPostGroupRows * kSlotBufElements * sizeof(float));
        pipe_->InitBuffer(hInOutQueue_, kQueueDepth, tileElements * sizeof(DT_X));
        pipe_->InitBuffer(hInXQueue_, kQueueDepth,
                          static_cast<uint32_t>(tiling_->streamCount) * hInTile_ * sizeof(DT_X));
        pipe_->InitBuffer(calcBuf_, tileElements * sizeof(float));
        pipe_->InitBuffer(reduceWorkBuf_, tileElements * sizeof(float));
        pipe_->InitBuffer(scalarBuf_, 16 * sizeof(float));
        // 每行一个 16-float 槽(8 个流 + 填充): n=6 时 Brcb 会读 2 个 32B block
        pipe_->InitBuffer(hPreBuf_, kPostGroupRows * 16 * sizeof(float));
        // 按 AIV 自己的行切分开归约缓冲。
        pipe_->InitBuffer(rowSumBuf_,
                          static_cast<uint32_t>(tiling_->vectorRowsPerCore * sizeof(float)));
        // gamma 每个 nD 分块只载入一次, 供该 worker 的所有行复用
        if (tiling_->hasGamma != 0) {
            pipe_->InitBuffer(gammaBuf_, tileElements * sizeof(float));
        }
        // 一批行的归约结果(按 8 元素跨距)
        pipe_->InitBuffer(batchSumBuf_, kSumBatchRows * kFloatBlockElements * sizeof(float));
        // hIn 批量归约: n 行 x 的 fp32 暂存与 Brcb 广播暂存
        pipe_->InitBuffer(hInXCastBuf_,
                          static_cast<uint32_t>(tiling_->streamCount) * hInTile_ * sizeof(float));
        pipe_->InitBuffer(brcbBuf_, 16 * (kBlkSize / sizeof(float)) * sizeof(float));
        // 后处理组级流水用的 hMix 槽位: 双组(当前组/下一组)交替, 每行 kSlotBufElements
        pipe_->InitBuffer(mixSlotBuf_, 2 * kPostGroupRows * kSlotBufElements * sizeof(float));
        pipe_->InitBuffer(biasSlotBuf_, kSlotBufElements * sizeof(float));
    }

    __aicore__ inline void GetVectorRowRange(uint64_t &rowStart, uint64_t &rowCount) const
    {
        // MIX 1:2 下 AIV 上 GetBlockIdx() 就是 0..2*blockDim-1 的向量核号
        const uint64_t vectorCore = static_cast<uint64_t>(GetBlockIdx());
        rowStart = vectorCore * tiling_->vectorRowsPerCore;
        if (rowStart >= tiling_->batchSeq) {
            rowStart = tiling_->batchSeq;
            rowCount = 0;
            return;
        }
        rowCount = MinU64(tiling_->vectorRowsPerCore, tiling_->batchSeq - rowStart);
    }

    __aicore__ inline void GetCubeRowRange(uint64_t &rowStart, uint64_t &rowCount) const
    {
        const uint64_t cubeCore = static_cast<uint64_t>(GetBlockIdx());
        rowStart = cubeCore * tiling_->rowsPerVector;
        if (rowStart >= tiling_->batchSeq) {
            rowStart = tiling_->batchSeq;
            rowCount = 0;
            return;
        }
        rowCount = MinU64(tiling_->rowsPerVector, tiling_->batchSeq - rowStart);
    }

    __aicore__ inline void PreprocessRows(uint64_t rowStart, uint64_t rowCount)
    {
        if (rowCount == 0) {
            return;
        }

        LocalTensor<float> calcLocal = calcBuf_.Get<float>();
        LocalTensor<float> reduceWorkLocal = reduceWorkBuf_.Get<float>();
        LocalTensor<float> scalarLocal = scalarBuf_.Get<float>();
        LocalTensor<float> rowSumLocal = rowSumBuf_.Get<float>();
        LocalTensor<float> batchSumLocal = batchSumBuf_.Get<float>();
        Duplicate(rowSumLocal, 0.0f, static_cast<uint32_t>(rowCount));
        PipeBarrier<PIPE_V>();

        // gamma is shared by every token. Keep one nD slice in UB and reuse
        // it for all rows owned by this worker instead of reloading per row.
        for (uint64_t flatOffset = 0; flatOffset < tiling_->flatDim;
             flatOffset += tiling_->tileElements) {
            const uint32_t current = static_cast<uint32_t>(
                MinU64(tiling_->tileElements, tiling_->flatDim - flatOffset));

            LocalTensor<float> gammaLocal;
            if (tiling_->hasGamma != 0) {
                gammaLocal = gammaBuf_.Get<float>();
                DataCopy(gammaLocal, gammaGm_[flatOffset], current);
                SyncMte2ToVector();
            }

            for (uint64_t rowOffset = 0; rowOffset < rowCount; ++rowOffset) {
                const uint64_t row = rowStart + rowOffset;
                const uint32_t localRow = static_cast<uint32_t>(rowOffset);

                LocalTensor<DT_X> xLocal = xQueue_.AllocTensor<DT_X>();
                DataCopy(xLocal, xGm_[row * tiling_->flatDim + flatOffset], current);
                xQueue_.EnQue(xLocal);
                xLocal = xQueue_.DeQue<DT_X>();

                LocalTensor<float> xCastLocal = xCastQueue_.AllocTensor<float>();
                Cast(xCastLocal, xLocal, RoundMode::CAST_NONE, current);
                xQueue_.FreeTensor(xLocal);
                PipeBarrier<PIPE_V>();

                Mul(calcLocal, xCastLocal, xCastLocal, current);
                PipeBarrier<PIPE_V>();
                // 归约结果按 8 元素跨距落在暂存区(保持 32B 对齐), 先不读回标量
                ReduceSum<float>(batchSumLocal[(localRow % kSumBatchRows) * kFloatBlockElements],
                                 calcLocal, reduceWorkLocal, static_cast<int32_t>(current));

                if (tiling_->hasGamma != 0) {
                    Mul(xCastLocal, xCastLocal, gammaLocal, current);
                    PipeBarrier<PIPE_V>();
                }
                xCastQueue_.EnQue(xCastLocal);
                xCastLocal = xCastQueue_.DeQue<float>();
                DataCopy(xGammaGm_[row * tiling_->flatDim + flatOffset], xCastLocal, current);
                xCastQueue_.FreeTensor(xCastLocal);

                // 攒满一批(或到本 worker 最后一行)才做一次 V->S, 把 64 次流水冲刷压成 1 次
                const bool lastRow = (rowOffset + 1 == rowCount);
                if ((localRow % kSumBatchRows) == kSumBatchRows - 1 || lastRow) {
                    const uint32_t batchBase = (localRow / kSumBatchRows) * kSumBatchRows;
                    const uint32_t batchLen = localRow - batchBase + 1;
                    SyncVectorToScalar();
                    for (uint32_t j = 0; j < batchLen; ++j) {
                        rowSumLocal.SetValue(batchBase + j,
                            rowSumLocal.GetValue(batchBase + j) +
                            batchSumLocal.GetValue(j * kFloatBlockElements));
                    }
                    SyncScalarToVector();
                }
            }
        }

        // Keep invRms in UB for this worker's postprocess instead of writing it
        // to workspace and issuing one scalar GM read per token.
        SyncScalarToVector();
        for (uint64_t rowOffset = 0; rowOffset < rowCount;
             rowOffset += tiling_->tileElements) {
            const uint32_t currentRows = static_cast<uint32_t>(
                MinU64(tiling_->tileElements, rowCount - rowOffset));
            LocalTensor<float> invLocal = rowSumLocal[static_cast<uint32_t>(rowOffset)];
            Muls(invLocal, invLocal, tiling_->invFlatDim, currentRows);
            PipeBarrier<PIPE_V>();
            Adds(invLocal, invLocal, tiling_->normEps, currentRows);
            PipeBarrier<PIPE_V>();
            Sqrt(invLocal, invLocal, currentRows);
            PipeBarrier<PIPE_V>();
            Duplicate(calcLocal, 1.0f, currentRows);
            PipeBarrier<PIPE_V>();
            Div(invLocal, calcLocal, invLocal, currentRows);
            PipeBarrier<PIPE_V>();
        }
    }

    __aicore__ inline void ProjectWithCube()
    {
        uint64_t rowStart = 0;
        uint64_t rowCount = 0;
        GetCubeRowRange(rowStart, rowCount);
        if (rowCount == 0) {
            return;
        }

        const uint32_t currentRows = static_cast<uint32_t>(rowCount);
        const uint64_t aOffset = rowStart * tiling_->flatDim;
        const uint64_t cOffset = rowStart * tiling_->mixDim;
        matmulObj.SetTensorA(xGammaGm_[aOffset]);
        matmulObj.SetTensorB(phiGm_, true);
        matmulObj.SetOrgShape(currentRows, tiling_->mixDim, tiling_->flatDim);
        matmulObj.SetSingleShape(currentRows, tiling_->mixDim, tiling_->flatDim);
        matmulObj.template IterateAll<false>(hMixGm_[cOffset]);
        matmulObj.End();
    }

    __aicore__ inline void Sigmoid(LocalTensor<float> dst, LocalTensor<float> src,
                                   LocalTensor<float> bias, LocalTensor<float> one,
                                   float scale, float epsilon, uint32_t count)
    {
        Muls(dst, src, scale, count);
        Add(dst, dst, bias, count);
        Muls(dst, dst, -1.0f, count);
        Exp(dst, dst, count);
        Adds(dst, dst, 1.0f, count);
        Div(dst, one, dst, count);
        if (epsilon != 0.0f) {
            Adds(dst, dst, epsilon, count);
        }
    }

    // GM 侧偏移任意, UB 侧落在对齐槽位 —— 用它把 bias 的三段搬进来
    __aicore__ inline void LoadSlice(LocalTensor<float> dst, GlobalTensor<float> src,
                                     uint64_t offset, uint32_t count)
    {
        DataCopyExtParams copyParams;
        copyParams.blockCount = 1;
        copyParams.blockLen = count * sizeof(float);
        copyParams.srcStride = 0;
        copyParams.dstStride = 0;
        DataCopyPadExtParams<float> padParams{false, 0, 0, 0.0f};
        DataCopyPad(dst, src[offset], copyParams, padParams);
    }

    // 把一组的 hMix(pPre/pPost/pRes 三段)用 3 次跨步 DataCopyPad 批量搬进双组槽位。
    // rows 行为一块, src 在 GM 按 mixDim 行距连续、dst 按 kSlotBufElements 槽距。
    // 每段各 32B 对齐(src/dst blockLen 均为 n 或 n*n 个 float)。
    __aicore__ inline void LoadMixGroup(uint32_t slotIndex, uint64_t mixRow,
                                        uint32_t rows, LocalTensor<float> mixSlots)
    {
        const uint32_t n = static_cast<uint32_t>(tiling_->streamCount);
        const uint32_t resCount = n * n;
        const uint32_t slotBase = slotIndex * kSlotBufElements;
        const uint64_t mixBase = mixRow * tiling_->mixDim;

        // DataCopyExtParams 的 blockLen/srcStride/dstStride 单位均为字节,
        // srcStride/dstStride 为"当前 block 结束到下个 block 开始"的间隔。
        DataCopyExtParams copyParams;
        DataCopyPadExtParams<float> padParams{false, 0, 0, 0.0f};
        copyParams.blockCount = rows;
        copyParams.blockLen = n * sizeof(float);
        copyParams.srcStride =
            static_cast<uint32_t>((tiling_->mixDim - n) * sizeof(float));
        copyParams.dstStride =
            static_cast<uint32_t>((kSlotBufElements - n) * sizeof(float));
        DataCopyPad(mixSlots[slotBase], hMixGm_[mixBase], copyParams, padParams);
        DataCopyPad(mixSlots[slotBase + kSlotPost], hMixGm_[mixBase + n], copyParams, padParams);

        copyParams.blockLen = resCount * sizeof(float);
        copyParams.srcStride =
            static_cast<uint32_t>((tiling_->mixDim - resCount) * sizeof(float));
        copyParams.dstStride =
            static_cast<uint32_t>((kSlotBufElements - resCount) * sizeof(float));
        DataCopyPad(mixSlots[slotBase + kSlotRes], hMixGm_[mixBase + 2 * n], copyParams, padParams);
    }

    // 组级 hPost/hRes 输出: 每行一个 block, src 在 96 宽槽位、GM 侧逐行连续。
    __aicore__ inline void CopyGroupOutput(GlobalTensor<float> dstGm, LocalTensor<float> srcSlot,
                                           uint32_t rows, uint32_t blockElements)
    {
        DataCopyExtParams copyParams;
        copyParams.blockCount = rows;
        copyParams.blockLen = blockElements * sizeof(float);
        copyParams.srcStride = (kSlotBufElements - blockElements) * sizeof(float);
        copyParams.dstStride = 0;
        DataCopyPad(dstGm, srcSlot, copyParams);
    }

    // 预取一个 hIn 分片: n 个 stream 各 current 元素, GM 中每 stream 行距 headDim。
    // dst 必须已由调用方 AllocTensor, 本函数负责 EnQue。
    __aicore__ inline void PrefetchHInX(LocalTensor<DT_X> &dst, uint64_t gmRow,
                                        uint64_t dimOffset, uint32_t current)
    {
        const uint32_t n = static_cast<uint32_t>(tiling_->streamCount);
        DataCopyExtParams copyParams;
        copyParams.blockCount = static_cast<uint16_t>(n);
        copyParams.blockLen = current * sizeof(DT_X);
        copyParams.srcStride =
            static_cast<uint32_t>((tiling_->headDim - current) * sizeof(DT_X));
        copyParams.dstStride = 0;
        DataCopyPadExtParams<DT_X> padParams{false, 0, 0, 0.0f};
        DataCopyPad(dst, xGm_[gmRow * tiling_->flatDim + dimOffset], copyParams, padParams);
        hInXQueue_.EnQue(dst);
    }

    __aicore__ inline void PostprocessRows(uint64_t rowStart, uint64_t rowCount)
    {
        if (rowCount == 0) {
            return;
        }

        const uint32_t n = static_cast<uint32_t>(tiling_->streamCount);
        const uint32_t resCount = n * n;
        const float alphaPre = alphaGm_.GetValue(0);
        const float alphaPost = alphaGm_.GetValue(1);
        const float alphaRes = alphaGm_.GetValue(2);

        LocalTensor<float> mixSlots = mixSlotBuf_.Get<float>();
        LocalTensor<float> biasSlot = biasSlotBuf_.Get<float>();
        LocalTensor<float> calcLocal = calcBuf_.Get<float>();
        LocalTensor<float> scalarLocal = scalarBuf_.Get<float>();
        LocalTensor<float> oneLocal = scalarLocal[kFloatBlockElements];
        LocalTensor<float> hPreLocal = hPreBuf_.Get<float>();
        LocalTensor<float> invRmsLocal = rowSumBuf_.Get<float>();
        LocalTensor<float> xCastLocal = hInXCastBuf_.Get<float>();
        LocalTensor<float> brcbLocal = brcbBuf_.Get<float>();
        const uint32_t mixStride = kSlotBufElements;

        // bias 的三段各自搬到对齐槽位, 只搬一次
        LoadSlice(biasSlot, biasGm_, 0, n);
        LoadSlice(biasSlot[kSlotPost], biasGm_, n, n);
        LoadSlice(biasSlot[kSlotRes], biasGm_, 2 * n, resCount);
        SyncMte2ToVector();
        Duplicate(oneLocal, 1.0f, kFloatBlockElements);
        PipeBarrier<PIPE_V>();
        // invRms 是前处理算好的行级标量, 一次冲刷让整轮都能直读标量缓存
        SyncVectorToScalar();

        // 预取第 0 组的 hMix 与第 0 行首个 x 分片(冷启动只等这一批)
        const uint32_t firstGroupRows = static_cast<uint32_t>(
            MinU64(kPostGroupRows, rowCount));
        LoadMixGroup(0, rowStart, firstGroupRows, mixSlots);
        if (rowCount > 0) {
            LocalTensor<DT_X> firstX = hInXQueue_.AllocTensor<DT_X>();
            PrefetchHInX(firstX, rowStart, 0, hInTile_);
        }

        for (uint64_t groupOffset = 0; groupOffset < rowCount; groupOffset += kPostGroupRows) {
            const uint32_t groupRows = static_cast<uint32_t>(
                MinU64(kPostGroupRows, rowCount - groupOffset));
            const uint32_t half = static_cast<uint32_t>((groupOffset / kPostGroupRows) % 2);
            const uint32_t slotBase = half * kPostGroupRows;

            // 1) 本组装载已在上一组的计算窗口内发出, 这里只等它落地
            SyncMte2ToVector();

            // 2) 预取下一组的 hMix(在当前组计算窗口内落地), 双组槽位交替
            const uint64_t nextStart = groupOffset + kPostGroupRows;
            if (nextStart < rowCount) {
                const uint32_t nextRows = static_cast<uint32_t>(
                    MinU64(kPostGroupRows, rowCount - nextStart));
                const uint32_t nextSlotBase = (1U - half) * kPostGroupRows;
                LoadMixGroup(nextSlotBase, rowStart + nextStart, nextRows, mixSlots);
            }

            // 3) 本组所有行的 hPre(纯向量写入 [组,16] 槽, 之后由 Brcb 直接消费)
            for (uint32_t j = 0; j < groupRows; ++j) {
                const float invRms =
                    invRmsLocal.GetValue(static_cast<uint32_t>(groupOffset + j));
                // w = hMix * invRms, 再乘 alpha —— 两个标量合并成一个, 少一趟向量运算
                Sigmoid(hPreLocal[j * 16],
                        mixSlots[(slotBase + j) * mixStride], biasSlot, oneLocal,
                        invRms * alphaPre, tiling_->hcEps, n);
            }

            // 4) 逐行 hPost/hRes(落入组级输出缓冲) + hIn(Brcb 批量归约)
            LocalTensor<float> outLocal = floatOutQueue_.AllocTensor<float>();
            for (uint32_t j = 0; j < groupRows; ++j) {
                const uint64_t row = rowStart + groupOffset + j;
                const float invRms =
                    invRmsLocal.GetValue(static_cast<uint32_t>(groupOffset + j));
                const LocalTensor<float> rowMix = mixSlots[(slotBase + j) * mixStride];
                const LocalTensor<float> rowOut = outLocal[j * mixStride];

                Sigmoid(rowOut[kSlotPost], rowMix[kSlotPost], biasSlot[kSlotPost],
                        oneLocal, invRms * alphaPost, 0.0f, n);
                Muls(rowOut[kSlotPost], rowOut[kSlotPost], 2.0f, n);
                PipeBarrier<PIPE_V>();

                Muls(rowOut[kSlotRes], rowMix[kSlotRes], invRms * alphaRes, resCount);
                PipeBarrier<PIPE_V>();
                Add(rowOut[kSlotRes], rowOut[kSlotRes], biasSlot[kSlotRes], resCount);
                PipeBarrier<PIPE_V>();

                // hIn: DeQue x 分片 -> 一次 Cast(n 行 x current) -> 一次广播乘 ->
                //      一次跨 n 归约 -> Cast 回 x 类型写出
                for (uint64_t dimOffset = 0; dimOffset < tiling_->headDim;
                     dimOffset += hInTile_) {
                    const uint32_t current = static_cast<uint32_t>(
                        MinU64(static_cast<uint64_t>(hInTile_), tiling_->headDim - dimOffset));

                    LocalTensor<DT_X> hInXLocal = hInXQueue_.DeQue<DT_X>();
                    const uint64_t nextOffset = dimOffset + hInTile_;
                    if (nextOffset < tiling_->headDim) {
                        const uint32_t nextCurrent = static_cast<uint32_t>(
                            MinU64(static_cast<uint64_t>(hInTile_), tiling_->headDim - nextOffset));
                        LocalTensor<DT_X> nextLocal = hInXQueue_.AllocTensor<DT_X>();
                        PrefetchHInX(nextLocal, row, nextOffset, nextCurrent);
                    } else if (row + 1 < rowStart + rowCount) {
                        LocalTensor<DT_X> nextLocal = hInXQueue_.AllocTensor<DT_X>();
                        PrefetchHInX(nextLocal, row + 1, 0, hInTile_);
                    }

                    for (uint32_t stream = 0; stream < n; ++stream) {
                        Cast(xCastLocal[stream * current], hInXLocal[stream * current],
                             RoundMode::CAST_NONE, current);
                    }
                    hInXQueue_.FreeTensor(hInXLocal);
                    PipeBarrier<PIPE_V>();
                    MulABLastDimBrcInline2<float>(xCastLocal, xCastLocal, hPreLocal[j * 16],
                                                  brcbLocal, static_cast<int32_t>(n),
                                                  static_cast<int32_t>(current),
                                                  static_cast<int32_t>(n));
                    ReduceSumARAPerf(calcLocal, xCastLocal, 1, n, current);

                    LocalTensor<DT_X> hInLocal = hInOutQueue_.AllocTensor<DT_X>();
                    Cast(hInLocal, calcLocal, RoundMode::CAST_RINT, current);
                    hInOutQueue_.EnQue(hInLocal);
                    hInLocal = hInOutQueue_.DeQue<DT_X>();
                    DataCopy(hInGm_[row * tiling_->headDim + dimOffset], hInLocal, current);
                    hInOutQueue_.FreeTensor(hInLocal);
                }
            }

            // 5) 组级输出: hPost/hRes 各一次跨组搬运(GM 侧行连续)
            floatOutQueue_.EnQue(outLocal);
            outLocal = floatOutQueue_.DeQue<float>();
            const uint64_t outRowBase = rowStart + groupOffset;
            CopyGroupOutput(hPostGm_[outRowBase * n], outLocal[kSlotPost], groupRows, n);
            CopyGroupOutput(hResGm_[outRowBase * resCount], outLocal[kSlotRes], groupRows,
                            resCount);
            floatOutQueue_.FreeTensor(outLocal);
        }
    }

    const MhcPreTilingData *tiling_ = nullptr;
    TPipe *pipe_ = nullptr;

    GlobalTensor<DT_X> xGm_;
    GlobalTensor<float> phiGm_;
    GlobalTensor<float> alphaGm_;
    GlobalTensor<float> biasGm_;
    GlobalTensor<float> gammaGm_;
    GlobalTensor<DT_X> hInGm_;
    GlobalTensor<float> hPostGm_;
    GlobalTensor<float> hResGm_;
    GlobalTensor<float> xGammaGm_;
    GlobalTensor<float> invRmsGm_;
    GlobalTensor<float> hMixGm_;

    TQue<QuePosition::VECIN, kQueueDepth> xQueue_;
    TQue<QuePosition::VECOUT, kQueueDepth> xCastQueue_;
    TQue<QuePosition::VECOUT, kQueueDepth> floatOutQueue_;
    TQue<QuePosition::VECOUT, kQueueDepth> hInOutQueue_;
    TQue<QuePosition::VECIN, kQueueDepth> hInXQueue_;
    TBuf<QuePosition::VECCALC> calcBuf_;
    TBuf<QuePosition::VECCALC> reduceWorkBuf_;
    TBuf<QuePosition::VECCALC> scalarBuf_;
    TBuf<QuePosition::VECCALC> hPreBuf_;
    TBuf<QuePosition::VECCALC> rowSumBuf_;
    TBuf<QuePosition::VECCALC> gammaBuf_;
    TBuf<QuePosition::VECCALC> batchSumBuf_;
    TBuf<QuePosition::VECCALC> hInXCastBuf_;
    TBuf<QuePosition::VECCALC> brcbBuf_;
    TBuf<QuePosition::VECCALC> mixSlotBuf_;
    TBuf<QuePosition::VECCALC> biasSlotBuf_;
    uint32_t hInTile_ = kHinTileElements;
};

template <typename DT_X>
__global__ __aicore__ void mhc_pre(GM_ADDR x, GM_ADDR phi, GM_ADDR alpha, GM_ADDR bias, GM_ADDR gamma,
                                   GM_ADDR hIn, GM_ADDR hPost, GM_ADDR hRes, GM_ADDR workspace, GM_ADDR tiling)
{
    KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_MIX_AIC_1_2);
    REGISTER_TILING_DEFAULT(MhcPreTilingData);
    GET_TILING_DATA_WITH_STRUCT(MhcPreTilingData, tilingData, tiling);
    if (workspace == nullptr) {
        return;
    }
    GM_ADDR userWorkspace = GetUserWorkspace(workspace);
    if (userWorkspace == nullptr) {
        return;
    }

    TPipe pipe;
    KernelMhcPre<DT_X> op;
    op.matmulObj.Init(&tilingData.cubeTilingData, &pipe);
    op.matmulObj.SetSubBlockIdx(0);
    op.Init(x, phi, alpha, bias, gamma, hIn, hPost, hRes, userWorkspace, &tilingData, &pipe);
    op.Process();
}
