#include "register/op_def_registry.h"
#include "tiling/platform/platform_ascendc.h"
#include "tiling/tiling_api.h"

#include "../op_kernel/mhc_pre_tiling.h"
#include "../op_kernel/tiling_key_mhc_pre.h"

namespace {
constexpr uint64_t kVectorTileElements = 2048;
constexpr uint64_t kCubeMAlignment = 16;
constexpr uint64_t kVectorRowsAlignment = kCubeMAlignment / 2;
constexpr uint64_t kMaxMixDim = 80;
// Fixed-M tiling matches CANN 8.0's proven official MhcPre stage-1 tiling M.
constexpr uint64_t M64_TILING_M = 64;

inline uint64_t CeilDiv(uint64_t value, uint64_t divisor)
{
    return (value + divisor - 1) / divisor;
}

inline uint64_t AlignUp(uint64_t value, uint64_t alignment)
{
    return CeilDiv(value, alignment) * alignment;
}
} // namespace

namespace optiling {
static ge::graphStatus TilingFunc(gert::TilingContext *context)
{
    if (context == nullptr) {
        return ge::GRAPH_FAILED;
    }

    const gert::Tensor *xTensor = context->GetRequiredInputTensor(0);
    const gert::Tensor *gammaTensor = context->GetOptionalInputTensor(4);
    if (xTensor == nullptr) {
        return ge::GRAPH_FAILED;
    }

    const gert::Shape &xShape = xTensor->GetOriginShape();
    if (xShape.GetDimNum() != 4) {
        return ge::GRAPH_FAILED;
    }

    const int64_t batchSigned = xShape.GetDim(0);
    const int64_t sequenceSigned = xShape.GetDim(1);
    const int64_t streamCountSigned = xShape.GetDim(2);
    const int64_t headDimSigned = xShape.GetDim(3);
    if (batchSigned <= 0 || sequenceSigned <= 0 || headDimSigned <= 0 ||
        (streamCountSigned != 4 && streamCountSigned != 6 && streamCountSigned != 8)) {
        return ge::GRAPH_FAILED;
    }
    const uint64_t batch = static_cast<uint64_t>(batchSigned);
    const uint64_t sequence = static_cast<uint64_t>(sequenceSigned);
    const uint64_t streamCount = static_cast<uint64_t>(streamCountSigned);
    const uint64_t headDim = static_cast<uint64_t>(headDimSigned);
    const uint64_t batchSeq = batch * sequence;
    const uint64_t flatDim = streamCount * headDim;
    const uint64_t mixDim = streamCount * streamCount + 2 * streamCount;

    auto platform = platform_ascendc::PlatformAscendC(context->GetPlatformInfo());
    const uint32_t aicCoreNum = static_cast<uint32_t>(platform.GetCoreNumAic());
    const uint32_t aivCoreNum = static_cast<uint32_t>(platform.GetCoreNumAiv());
    if (aicCoreNum == 0 || aivCoreNum != 2U * aicCoreNum || batchSeq == 0 ||
        flatDim == 0 || mixDim > kMaxMixDim || (flatDim % 8U) != 0U ||
        (headDim % 16U) != 0U) {
        return ge::GRAPH_FAILED;
    }

    // One AIC is paired with two AIVs in MIX_AIC_1_2.  Make the two adjacent
    // AIV slices concatenate exactly into the corresponding AIC slice.  The
    // 8-row AIV alignment also keeps the resulting AIC M extent 16-aligned.
    // Original tiling semantics: rowsPerVector carries the AIC-side M slice,
    // which is exactly the concatenation of the two paired AIV slices.
    const uint64_t vectorRowsPerCore =
        AlignUp(CeilDiv(batchSeq, static_cast<uint64_t>(aivCoreNum)), kVectorRowsAlignment);
    const uint64_t rowsPerVector = 2U * vectorRowsPerCore;

    MhcPreTilingData *tiling = context->GetTilingData<MhcPreTilingData>();
    if (tiling == nullptr) {
        return ge::GRAPH_FAILED;
    }
    tiling->batchSeq = batchSeq;
    tiling->streamCount = streamCount;
    tiling->headDim = headDim;
    tiling->flatDim = flatDim;
    tiling->mixDim = mixDim;
    tiling->rowsPerVector = rowsPerVector;
    tiling->vectorRowsPerCore = vectorRowsPerCore;
    tiling->aicCoreNum = aicCoreNum;
    tiling->aivCoreNum = aivCoreNum;
    tiling->tileElements = static_cast<uint32_t>(kVectorTileElements);
    tiling->hasGamma = (gammaTensor != nullptr && gammaTensor->GetShapeSize() > 0) ? 1U : 0U;
    tiling->invFlatDim = 1.0f / static_cast<float>(flatDim);

    const gert::RuntimeAttrs *attrs = context->GetAttrs();
    const float *normEps = attrs == nullptr ? nullptr : attrs->GetFloat(0);
    const float *hcEps = attrs == nullptr ? nullptr : attrs->GetFloat(1);
    tiling->normEps = normEps == nullptr ? 1.0e-6f : *normEps;
    tiling->hcEps = hcEps == nullptr ? 1.0e-6f : *hcEps;

    // Build a single-AIC Matmul tiling.  The kernel instantiates MatmulImpl
    // directly on the Cube core.  CANN 8.0's official MhcPre stage-1 tiling
    // feeds MatmulApiTiling with a fixed M=64 (two AIVs x 32 rows per round),
    // so this variant tiles with the same proven M while each AIC drives the
    // whole slice through the kernel-side SetSingleShape/SetOrgShape (SetTail).
    matmul_tiling::MatmulApiTiling cubeTiling(platform);
    cubeTiling.SetAType(matmul_tiling::TPosition::GM, matmul_tiling::CubeFormat::ND,
                        matmul_tiling::DataType::DT_FLOAT);
    cubeTiling.SetBType(matmul_tiling::TPosition::GM, matmul_tiling::CubeFormat::ND,
                        matmul_tiling::DataType::DT_FLOAT, true);
    cubeTiling.SetCType(matmul_tiling::TPosition::GM, matmul_tiling::CubeFormat::ND,
                        matmul_tiling::DataType::DT_FLOAT);
    cubeTiling.SetOrgShape(M64_TILING_M, mixDim, flatDim);
    cubeTiling.SetShape(M64_TILING_M, mixDim, flatDim);
    cubeTiling.SetBias(false);
    cubeTiling.SetBufferSpace(-1, -1, -1);
    if (cubeTiling.GetTiling(tiling->cubeTilingData) == -1) {
        return ge::GRAPH_FAILED;
    }

    const ge::DataType xType = xTensor->GetDataType();
    const uint32_t DT_X = static_cast<uint32_t>(xType);
    ASCENDC_TPL_SEL_PARAM(context, DT_X);

    context->SetBlockDim(aicCoreNum);

    // User workspace layout: xGamma(fp32), invRms(fp32), hMix(fp32).
    const uint64_t xGammaBytes = batchSeq * flatDim * sizeof(float);
    const uint64_t invRmsBytes = batchSeq * sizeof(float);
    const uint64_t hMixBytes = batchSeq * mixDim * sizeof(float);
    const uint64_t userWorkspaceBytes = xGammaBytes + invRmsBytes + hMixBytes;
    const size_t systemWorkspaceBytes = static_cast<size_t>(platform.GetLibApiWorkSpaceSize());
    size_t *workspaceSizes = context->GetWorkspaceSizes(1);
    workspaceSizes[0] = static_cast<size_t>(userWorkspaceBytes) + systemWorkspaceBytes;
    return ge::GRAPH_SUCCESS;
}
} // namespace optiling

namespace ge {
static graphStatus InferShape(gert::InferShapeContext *context)
{
    const gert::Shape *xShape = context->GetInputShape(0);
    gert::Shape *hInShape = context->GetOutputShape(0);
    gert::Shape *hPostShape = context->GetOutputShape(1);
    gert::Shape *hResShape = context->GetOutputShape(2);
    if (xShape == nullptr || hInShape == nullptr || hPostShape == nullptr || hResShape == nullptr ||
        xShape->GetDimNum() != 4) {
        return GRAPH_FAILED;
    }

    const int64_t batch = xShape->GetDim(0);
    const int64_t sequence = xShape->GetDim(1);
    const int64_t streamCount = xShape->GetDim(2);
    const int64_t headDim = xShape->GetDim(3);

    hInShape->SetDimNum(3);
    hInShape->SetDim(0, batch);
    hInShape->SetDim(1, sequence);
    hInShape->SetDim(2, headDim);

    hPostShape->SetDimNum(3);
    hPostShape->SetDim(0, batch);
    hPostShape->SetDim(1, sequence);
    hPostShape->SetDim(2, streamCount);

    hResShape->SetDimNum(4);
    hResShape->SetDim(0, batch);
    hResShape->SetDim(1, sequence);
    hResShape->SetDim(2, streamCount);
    hResShape->SetDim(3, streamCount);
    return GRAPH_SUCCESS;
}

static graphStatus InferDataType(gert::InferDataTypeContext *context)
{
    context->SetOutputDataType(0, context->GetInputDataType(0));
    context->SetOutputDataType(1, ge::DT_FLOAT);
    context->SetOutputDataType(2, ge::DT_FLOAT);
    return GRAPH_SUCCESS;
}
} // namespace ge

namespace ops {
class MhcPre : public OpDef {
public:
    explicit MhcPre(const char *name) : OpDef(name)
    {
        this->Input("x")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT16, ge::DT_BF16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND});
        this->Input("phi")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT, ge::DT_FLOAT})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND});
        this->Input("alpha")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT, ge::DT_FLOAT})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND});
        this->Input("bias")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT, ge::DT_FLOAT})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND});
        this->Input("gamma")
            .ParamType(OPTIONAL)
            .DataType({ge::DT_FLOAT, ge::DT_FLOAT})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND});
        this->Output("hIn")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT16, ge::DT_BF16})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND});
        this->Output("hPost")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT, ge::DT_FLOAT})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND});
        this->Output("hRes")
            .ParamType(REQUIRED)
            .DataType({ge::DT_FLOAT, ge::DT_FLOAT})
            .Format({ge::FORMAT_ND, ge::FORMAT_ND});
        this->Attr("normEps").AttrType(OPTIONAL).Float(1.0e-6f);
        this->Attr("hcEps").AttrType(OPTIONAL).Float(1.0e-6f);
        this->SetInferShape(ge::InferShape).SetInferDataType(ge::InferDataType);
        this->AICore().SetTiling(optiling::TilingFunc).AddConfig("ascend910b");
    }
};

OP_ADD(MhcPre);
} // namespace ops
